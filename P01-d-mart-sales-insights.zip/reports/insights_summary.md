# Business Insights Summary

## 📌 Key Findings

- **Top-selling products**: Snacks and Beverages lead in volume and revenue.
- **Underperforming categories**: Frozen foods show low sales in tier-2 locations.
- **Store trends**: Urban stores outperform rural ones by 35%.
- **Seasonal spikes**: Festive seasons show a 50% increase in grocery sales.

## 📈 Recommendations

- Increase stock for top products in festive months.
- Run promotions in underperforming categories.
- Analyze customer feedback for rural stores to improve engagement.
