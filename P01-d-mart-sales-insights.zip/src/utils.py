def format_currency(val):
    return f"₹{val:,.2f}"
