import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

const crimeTrendData = [
  { month: "Jan", crimes: 120 },
  { month: "Feb", crimes: 140 },
  { month: "Mar", crimes: 100 },
  { month: "Apr", crimes: 160 },
  { month: "May", crimes: 180 },
];

const typeDistributionData = [
  { type: "Theft", count: 50 },
  { type: "Fraud", count: 40 },
  { type: "Assault", count: 30 },
  { type: "Cybercrime", count: 60 },
  { type: "Smuggling", count: 20 },
];

const predictiveHeatData = [
  { region: "East", risk: 70 },
  { region: "North", risk: 85 },
  { region: "South", risk: 60 },
  { region: "West", risk: 75 },
  { region: "Central", risk: 90 },
];

export default function Dashboard() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
      <Card>
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Monthly Crime Trends</h2>
          <LineChart width={500} height={300} data={crimeTrendData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="crimes" stroke="#8884d8" />
          </LineChart>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Crime Type Distribution</h2>
          <BarChart width={500} height={300} data={typeDistributionData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="type" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="count" fill="#82ca9d" />
          </BarChart>
        </CardContent>
      </Card>

      <Card className="md:col-span-2">
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Predictive Crime Heatmap by Region</h2>
          <AreaChart width={1000} height={300} data={predictiveHeatData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="region" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="risk" stroke="#ffc658" fill="#ffd27f" />
          </AreaChart>
        </CardContent>
      </Card>
    </div>
  );
}
