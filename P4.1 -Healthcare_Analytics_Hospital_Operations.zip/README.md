# Healthcare Analytics - Optimizing Hospital Operations

## Objective
Visualize patient vitals, monitor ICU usage, and track KPIs such as ALOS and readmission rates.

## Structure
- `data/`: Raw and cleaned patient data.
- `src/`: Scripts for preprocessing, analytics, and visualizations.
- `outputs/`: Charts and reports on healthcare operations.
- `notebooks/`: Jupyter notebooks for exploration and dashboarding.

## KPIs
- ICU Usage Rate
- Average Length of Stay (ALOS)
- Readmission Rate

## Instructions
1. Run data preprocessing: `python src/data_preprocessing.py`
2. Run analytics: `python src/analytics.py`
3. Generate visualizations: `python src/visualization.py`