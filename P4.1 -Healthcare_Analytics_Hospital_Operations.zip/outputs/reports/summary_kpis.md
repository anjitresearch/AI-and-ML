# Hospital Operations Summary

- ICU Usage Rate: Calculated from patient vitals dataset.
- ALOS: Derived from Length of Stay column.
- Readmission Rate: Based on follow-up entries.