import pandas as pd
import matplotlib.pyplot as plt

def plot_vitals(df):
    df.groupby('Date')['Heart_Rate'].mean().plot(figsize=(10,5), title='Average Heart Rate Over Time')
    plt.ylabel('Heart Rate')
    plt.tight_layout()
    plt.savefig('outputs/charts/heart_rate_trend.png')

if __name__ == "__main__":
    df = pd.read_csv('data/processed/cleaned_vitals.csv')
    df['Date'] = pd.to_datetime(df['Date'])
    plot_vitals(df)