import pandas as pd

def preprocess_data(filepath):
    df = pd.read_csv(filepath)
    df['Date'] = pd.to_datetime(df['Date'])
    return df

if __name__ == "__main__":
    df = preprocess_data('data/raw/patient_vitals.csv')
    df.to_csv('data/processed/cleaned_vitals.csv', index=False)