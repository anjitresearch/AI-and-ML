import pandas as pd

def calculate_kpis(df):
    icu_usage = df['ICU_Bed_Used'].mean()
    alos = df['LOS_Days'].mean()
    readmission_rate = df['Readmitted'].mean()
    return icu_usage, alos, readmission_rate

if __name__ == "__main__":
    df = pd.read_csv('data/processed/cleaned_vitals.csv')
    icu, alos, readmit = calculate_kpis(df)
    print(f"ICU Usage Rate: {icu:.2f}")
    print(f"ALOS: {alos:.2f} days")
    print(f"Readmission Rate: {readmit:.2f}")