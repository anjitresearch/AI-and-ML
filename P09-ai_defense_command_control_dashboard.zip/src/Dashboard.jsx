import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from "recharts";

const threatLevelData = [
  { time: "10:00", level: 20 },
  { time: "10:30", level: 35 },
  { time: "11:00", level: 30 },
  { time: "11:30", level: 60 },
  { time: "12:00", level: 80 },
];

const resourceAllocationData = [
  { sector: "North", personnel: 120 },
  { sector: "East", personnel: 90 },
  { sector: "West", personnel: 70 },
  { sector: "South", personnel: 110 },
  { sector: "Central", personnel: 100 },
];

const capabilityMetrics = [
  { capability: "Surveillance", value: 90 },
  { capability: "Reconnaissance", value: 85 },
  { capability: "Mobility", value: 75 },
  { capability: "Firepower", value: 80 },
  { capability: "Communication", value: 95 },
];

export default function Dashboard() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
      <Card>
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Real-Time Threat Levels</h2>
          <AreaChart width={500} height={300} data={threatLevelData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="level" stroke="#ff7300" fill="#ffbb28" />
          </AreaChart>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Resource Allocation by Sector</h2>
          <LineChart width={500} height={300} data={resourceAllocationData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="sector" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="personnel" stroke="#8884d8" />
          </LineChart>
        </CardContent>
      </Card>

      <Card className="md:col-span-2">
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Operational Capability Metrics</h2>
          <RadarChart outerRadius={120} width={500} height={400} data={capabilityMetrics}>
            <PolarGrid />
            <PolarAngleAxis dataKey="capability" />
            <PolarRadiusAxis angle={30} domain={[0, 100]} />
            <Radar name="Capability" dataKey="value" stroke="#82ca9d" fill="#82ca9d" fillOpacity={0.6} />
            <Tooltip />
          </RadarChart>
        </CardContent>
      </Card>
    </div>
  );
}
