import pandas as pd
import matplotlib.pyplot as plt

def plot_top_skills(df):
    top_skills = df['skill'].value_counts().head(10)
    top_skills.plot(kind='barh', color='skyblue')
    plt.title('Top 10 IT Skills in India')
    plt.xlabel('Frequency')
    plt.tight_layout()
    plt.savefig('outputs/charts/top_skills_bar_chart.png')

if __name__ == "__main__":
    df = pd.read_csv('data/processed/it_skills_cleaned.csv')
    plot_top_skills(df)