import pandas as pd

def analyze_skills(df):
    return df['skill'].value_counts().head(10)

if __name__ == "__main__":
    df = pd.read_csv('data/processed/it_skills_cleaned.csv')
    print(analyze_skills(df))