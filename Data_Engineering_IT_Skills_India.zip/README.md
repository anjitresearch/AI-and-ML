# Data Engineering - Data-Driven Insights on IT Skills in India

## Objective
Gain insights into the most in-demand IT skills in India using data engineering pipelines.

## Structure
- `data/`: Contains raw, processed, and external datasets.
- `src/`: Scripts for data ingestion, cleaning, analysis, and visualization.
- `outputs/`: Charts and reports generated from analysis.
- `notebooks/`: Interactive EDA using Jupyter Notebooks.

## Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run data pipeline: `python src/data_ingestion.py`, `data_cleaning.py`, etc.