import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell } from "recharts";

const churnData = [
  { month: "Jan", churn: 5 },
  { month: "Feb", churn: 7 },
  { month: "Mar", churn: 4 },
  { month: "Apr", churn: 6 },
  { month: "May", churn: 3 },
];

const revenueData = [
  { stream: "Subscriptions", revenue: 40000 },
  { stream: "Upsells", revenue: 15000 },
  { stream: "Add-ons", revenue: 10000 },
  { stream: "Services", revenue: 20000 },
];

const satisfactionData = [
  { name: "Promoters", value: 60 },
  { name: "Passives", value: 25 },
  { name: "Detractors", value: 15 },
];

const COLORS = ["#00C49F", "#FFBB28", "#FF8042"];

export default function Dashboard() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
      <Card>
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Churn Prediction</h2>
          <LineChart width={500} height={300} data={churnData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis domain={[0, 10]} />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="churn" stroke="#8884d8" />
          </LineChart>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Revenue Streams</h2>
          <BarChart width={500} height={300} data={revenueData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="stream" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="revenue" fill="#82ca9d" />
          </BarChart>
        </CardContent>
      </Card>

      <Card className="md:col-span-2">
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Customer Satisfaction (NPS)</h2>
          <PieChart width={400} height={300}>
            <Pie
              data={satisfactionData}
              cx="50%"
              cy="50%"
              outerRadius={100}
              label
              dataKey="value"
            >
              {satisfactionData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </CardContent>
      </Card>
    </div>
  );
}
