import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

const oeeData = [
  { date: "Mon", oee: 85 },
  { date: "Tue", oee: 80 },
  { date: "Wed", oee: 78 },
  { date: "Thu", oee: 88 },
  { date: "Fri", oee: 90 },
];

const defectRateData = [
  { process: "Welding", defects: 4 },
  { process: "Painting", defects: 2 },
  { process: "Assembly", defects: 5 },
  { process: "Packaging", defects: 1 },
];

const maintenanceData = [
  { machine: "Press 1", risk: 65 },
  { machine: "Cutter 2", risk: 75 },
  { machine: "Welder 3", risk: 55 },
  { machine: "Paint Booth", risk: 70 },
];

export default function Dashboard() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
      <Card>
        <CardContent>
          <h2 className="text-xl font-bold mb-4">OEE (Overall Equipment Effectiveness)</h2>
          <LineChart width={500} height={300} data={oeeData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="oee" stroke="#8884d8" activeDot={{ r: 8 }} />
          </LineChart>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Defect Rates</h2>
          <BarChart width={500} height={300} data={defectRateData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="process" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="defects" fill="#82ca9d" />
          </BarChart>
        </CardContent>
      </Card>

      <Card className="md:col-span-2">
        <CardContent>
          <h2 className="text-xl font-bold mb-4">Predictive Maintenance Risk</h2>
          <BarChart width={1000} height={300} data={maintenanceData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="machine" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Legend />
            <Bar dataKey="risk" fill="#ffc658" />
          </BarChart>
        </CardContent>
      </Card>
    </div>
  );
}
