# Supply Chain Optimization

## Objective
Optimize logistics routes, reduce delivery delays, and manage warehouse inventory using real-time data and analytics.

## How to Run
1. Run `data_preprocessing.py` to clean the data.
2. Run `analytics.py` to extract key statistics.
3. Run `visualization.py` to generate visual reports.