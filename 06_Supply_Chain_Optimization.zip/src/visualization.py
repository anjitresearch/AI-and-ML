import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def plot_delivery_distribution(df):
    plt.figure(figsize=(8, 5))
    sns.histplot(df['Delivery_Time_Hours'], bins=15, kde=True)
    plt.title('Delivery Time Distribution')
    plt.xlabel('Hours')
    plt.ylabel('Frequency')
    plt.tight_layout()
    plt.savefig('outputs/charts/delivery_distribution.png')

def plot_inventory_heatmap(df):
    pivot = df.pivot_table(index='Warehouse', columns='Route', values='Inventory_Level', aggfunc='mean')
    plt.figure(figsize=(6, 4))
    sns.heatmap(pivot, annot=True, fmt=".0f", cmap='YlGnBu')
    plt.title('Average Inventory Level per Route/Warehouse')
    plt.tight_layout()
    plt.savefig('outputs/charts/inventory_heatmap.png')

if __name__ == "__main__":
    df = pd.read_csv('data/processed/cleaned_data.csv')
    plot_delivery_distribution(df)
    plot_inventory_heatmap(df)