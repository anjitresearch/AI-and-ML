import pandas as pd

def preprocess_data(filepath):
    df = pd.read_csv(filepath)
    df.dropna(inplace=True)
    return df

if __name__ == "__main__":
    df = preprocess_data('data/raw/supply_chain_data.csv')
    df.to_csv('data/processed/cleaned_data.csv', index=False)