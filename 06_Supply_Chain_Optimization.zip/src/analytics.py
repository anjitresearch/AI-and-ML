import pandas as pd

def delivery_stats(df):
    avg_delivery_time = df['Delivery_Time_Hours'].mean()
    delay_rate = df['Delay_Flag'].mean()
    return avg_delivery_time, delay_rate

def inventory_stats(df):
    avg_inventory = df['Inventory_Level'].mean()
    low_stock = df[df['Inventory_Level'] < 50]
    return avg_inventory, low_stock.shape[0]

if __name__ == "__main__":
    df = pd.read_csv('data/processed/cleaned_data.csv')
    avg_time, delay_rate = delivery_stats(df)
    avg_inventory, low_stock_count = inventory_stats(df)

    print("=== Delivery Analysis ===")
    print(f"Average Delivery Time: {avg_time:.2f} hours")
    print(f"Delay Rate: {delay_rate:.2%}")

    print("\n=== Inventory Analysis ===")
    print(f"Average Inventory Level: {avg_inventory:.2f}")
    print(f"Number of Low Stock Items: {low_stock_count}")