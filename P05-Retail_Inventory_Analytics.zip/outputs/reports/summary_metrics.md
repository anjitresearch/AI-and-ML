# Retail Analytics Summary

- **Customer Lifetime Value (CLV)**: Aggregated purchase value per customer.
- **Stock Turnover Ratio**: Measures stock efficiency and sales speed.
- **Sales Trends**: Daily revenue trends identified through visualizations.