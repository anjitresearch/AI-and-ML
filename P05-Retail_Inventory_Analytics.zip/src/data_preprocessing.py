import pandas as pd

def preprocess(filepath):
    df = pd.read_csv(filepath)
    df['Date'] = pd.to_datetime(df['Date'])
    return df

if __name__ == "__main__":
    df = preprocess('data/raw/sales_data.csv')
    df.to_csv('data/processed/cleaned_sales.csv', index=False)