import pandas as pd
import matplotlib.pyplot as plt

def plot_sales(df):
    df.groupby('Date')['Purchase_Amount'].sum().plot(title='Daily Sales Trend', figsize=(10,5))
    plt.ylabel('Sales (₹)')
    plt.tight_layout()
    plt.savefig('outputs/charts/sales_trend.png')

if __name__ == "__main__":
    df = pd.read_csv('data/processed/cleaned_sales.csv')
    df['Date'] = pd.to_datetime(df['Date'])
    plot_sales(df)