import pandas as pd

def calculate_metrics(df):
    clv = df.groupby('Customer_ID')['Purchase_Amount'].sum().mean()
    stock_turnover = (df['Units_Sold'].sum() / df['Stock_Remaining'].replace(0, 1).sum())
    return clv, stock_turnover

if __name__ == "__main__":
    df = pd.read_csv('data/processed/cleaned_sales.csv')
    clv, turnover = calculate_metrics(df)
    print(f"Avg Customer Lifetime Value (CLV): ₹{clv:.2f}")
    print(f"Stock Turnover Ratio: {turnover:.2f}")