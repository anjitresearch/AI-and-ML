# Retail & Inventory Analytics

## Objective
Analyze sales trends, predict stock shortages, and improve sales using segmentation and key retail metrics.

## Structure
- `data/`: Includes raw and cleaned retail sales data.
- `src/`: Contains scripts for preprocessing, analytics, and visualizations.
- `outputs/`: Charts and summary reports.
- `notebooks/`: For Jupyter dashboarding and exploration.

## Key Metrics
- Customer Lifetime Value (CLV)
- Stock Turnover Ratio

## Instructions
1. Preprocess the data: `python src/data_preprocessing.py`
2. Run analytics: `python src/analytics.py`
3. Generate sales visualization: `python src/visualization.py`