import pandas as pd

def load_raw_data(path):
    return pd.read_csv(path)

if __name__ == "__main__":
    df = load_raw_data('data/raw/covid19_vellore_raw.csv')
    print(df.head())