import pandas as pd
import matplotlib.pyplot as plt

def plot_infections_by_location(df):
    counts = df['location'].value_counts()
    counts.plot(kind='bar', color='salmon')
    plt.title('COVID-19 Cases by Location in Vellore District')
    plt.ylabel('Number of Cases')
    plt.tight_layout()
    plt.savefig('outputs/charts/infection_by_location.png')

if __name__ == "__main__":
    df = pd.read_csv('data/processed/covid19_vellore_cleaned.csv')
    plot_infections_by_location(df)