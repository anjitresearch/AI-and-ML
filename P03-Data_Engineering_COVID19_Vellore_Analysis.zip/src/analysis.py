import pandas as pd

def infection_by_location(df):
    return df['location'].value_counts()

if __name__ == "__main__":
    df = pd.read_csv('data/processed/covid19_vellore_cleaned.csv')
    print(infection_by_location(df))