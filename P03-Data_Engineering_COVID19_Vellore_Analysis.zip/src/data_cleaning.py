import pandas as pd

def clean_data(df):
    df = df.dropna()
    df.columns = [col.strip().lower().replace(' ', '_') for col in df.columns]
    df['infection_date'] = pd.to_datetime(df['infection_date'])
    return df

if __name__ == "__main__":
    raw_df = pd.read_csv('data/raw/covid19_vellore_raw.csv')
    cleaned_df = clean_data(raw_df)
    cleaned_df.to_csv('data/processed/covid19_vellore_cleaned.csv', index=False)