# Data Engineering - COVID-19 Infection Pattern Analysis in Vellore District

## Objective
Analyze 1,000 COVID-19 records using data engineering and analytics to discover patterns in Vellore district.

## Structure
- `data/`: Raw, processed, and external datasets.
- `src/`: Scripts for data ingestion, cleaning, analysis, and visualization.
- `outputs/`: Generated charts and insights.
- `notebooks/`: Jupyter notebooks for EDA.

## Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run pipeline: `python src/data_ingestion.py`, `data_cleaning.py`, etc.