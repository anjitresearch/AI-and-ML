# Application Architecture with Deployment - API Testing Project

## Objective
Build and test an API using Postman, JMeter, and OWASP tools. Conduct functional, performance, and security tests.

## Structure
- `api/`: Source code for the API.
- `tests/`: Functional (Postman), Performance (JMeter), and Security (OWASP) test plans.
- `reports/`: Summarized findings from each test category.
- `docs/`: Additional documentation or deployment guides.

## Run the API
```bash
pip install flask
python api/app.py
```

## Tools Used
- Postman for functional testing
- Apache JMeter for performance testing
- OWASP ZAP for security testing